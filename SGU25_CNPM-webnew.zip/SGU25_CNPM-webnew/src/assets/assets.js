import basket_icon from './basket_icon.png'
import logo from './logo.png'
import header_img from './header_img.png'
import search_icon from './search_icon.png'
import menu_1 from './g_gi_n_vui_v_-_4.png'
import menu_2 from './g_gi_n_vui_v_-_8_1_1.png'
import menu_3 from './burger_-_7.png'
import menu_4 from './m_jolly_-_6_7-compressed_1.jpg'
import menu_5 from './m_n_tr_ng_mi_ng_-_1.png'
import menu_6 from './th_c_u_ng_-_5_6_1.png'


import food_1 from './D.BUCKET2 (1).jpg'
import food_2 from './D.BUCKET5.jpg'
import food_3 from './DBUCKET1.jpg'
import food_4 from './1PCS.jpg'
import food_5 from './DBUCKET4 (1).jpg'
import food_6 from './1-GA-XOT.jpg'
import food_7 from './PHILE-XOT.jpg'
import food_8 from './Burger-Flava.jpg'
import food_9 from './Burger-Shrimp.jpg'
import food_10 from './Burger-Zinger.jpg'
import food_11 from './MIGAXUXI (1).jpg'
import food_12 from './MIGAXUXI-GA-RAN.jpg'
import food_13 from './MIGAXUXI-GA-VIEN.jpg'
import food_14 from './FF-L (1).jpg'
import food_15 from './khoai-mui-cau-R.jpg'
import food_17 from './EGGTART-4.jpg'
import food_18 from './EGGTART-1.jpg'
import food_19 from './4-Chewy-Cheese.jpg'
import food_20 from './2-taro.jpg'
import food_21 from './AQUAFINA.jpg'
import food_22 from './7UP_CAN.jpg'
import food_23 from './LIPTON-M.jpg'
import food_24 from './PEPSI-ZERO-M.jpg'


import add_icon_white from './add_icon_white.png'
import add_icon_green from './add_icon_green.png'
import remove_icon_red from './remove_icon_red.png'
import remove_icon_cross from './remove_icon_cross.png'
import app_store from './app_store.png'
import play_store from './play_store.png'
import linkedin_icon from './linkedin_icon.png'
import facebook_icon from './facebook_icon.png'
import twitter_icon from './twitter_icon.png'
import cross_icon from './cross_icon.png'
import selector_icon from './selector_icon.png'
import rating_starts from './rating_starts.png'
import profile_icon from './profile_icon.png'
import bag_icon from './bag_icon.png'
import logout_icon from './logout_icon.png'
import parcel_icon from './parcel_icon.png'
import user_icon from './10609407.png'

export const assets = {
    logo,
    basket_icon,
    header_img,
    search_icon,
    rating_starts,
    add_icon_green,
    add_icon_white,
    remove_icon_red,
    remove_icon_cross,
    app_store,
    play_store,
    linkedin_icon,
    facebook_icon,
    twitter_icon,
    cross_icon,
    selector_icon,
    profile_icon,
    logout_icon,
    bag_icon,
    parcel_icon,
    user_icon
}

export const menu_list = [
    {
        menu_name: "Combo",
        menu_image: menu_1
    },
    {
        menu_name: "Gà",
        menu_image: menu_2
    },
    {
        menu_name: "Hambuger",
        menu_image: menu_3
    },
    {
        menu_name: "Mỳ ý",
        menu_image: menu_4
    },
    {
        menu_name: "Thức ăn nhẹ",
        menu_image: menu_5
    },
    {
        menu_name: "Nước uống",
        menu_image: menu_6
    }

]
export const food_list = [
    {
        _id: "1",
        name: "Combo Nhóm 3 Đủ Đầy",
        image: food_1,
        price: 219000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Combo"
    },
    {
        _id: "2",
        name: "Combo Nhóm 2 Tròn Vị ",
        image: food_2,
        price: 160000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Combo"
    }, {
        _id: "3",
        name: "Combo Nhóm 2 Hoàn Hảo",
        image: food_3,
        price: 135000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Combo"
    }, {
        _id: "4",
        name: "Combo Nhóm 2 No Nê",
        image: food_5,
        price: 179000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Combo"
    }, {
        _id: "5",
        name: "Gà Xốt Mắm Tỏi",
        image: food_4,
        price: 45000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Gà"
    }, {
        _id: "6",
        name: "Gà Rán",
        image: food_6,
        price: 35000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Gà"
    }, {
        _id: "7",
        name: "Phi Lê Gà Quay",
        image: food_7,
        price: 42000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Gà"
    }, {
        _id: "8",
        name: "Burger Gà Quay Flava",
        image: food_8,
        price: 54000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Hambuger"
    }, {
        _id: "9",
        name: "Burger Tôm",
        image: food_9,
        price: 45000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Hambuger"
    }, {
        _id: "10",
        name: "Burger Zinger",
        image: food_10,
        price: 54000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Hambuger"
    }, {
        _id: "11",
        name: "Mì Migaxuxi ",
        image: food_11,
        price: 35000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Mỳ ý"
    }, {
        _id: "12",
        name: "Mì Migaxuxi Gà Rán",
        image: food_12,
        price: 64000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Mỳ ý"
    },
    {
        _id: "13",
        name: "Mì Migaxuxi Gà Viên",
        image: food_13,
        price: 45000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Mỳ ý"
    }, {
        _id: "14",
        name: "Khoai Tây Chiên",
        image: food_14,
        price: 29000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Thức ăn nhẹ"
    },
     {
        _id: "15",
        name: "Khoai Tây Múi Cau",
        image: food_15,
        price: 23000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Thức ăn nhẹ"
    },
     {
        _id: "16",
        name: "4 Bánh trứng",
        image: food_17,
        price: 64000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Thức ăn nhẹ"
    }, {
        _id: "17",
        name: "1 Bánh trứng",
        image: food_18,
        price: 18000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Thức ăn nhẹ"
    }, {
        _id: "18",
        name: "Phô Mai Viên",
        image: food_19,
        price: 36000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Thức ăn nhẹ"
    }, {
        _id: "19",
        name: "Khoai Môn Viên Kim Sa",
        image: food_20,
        price: 28000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Thức ăn nhẹ"
    }, {
        _id: "20",
        name: "Aquafina 500ml ",
        image: food_21,
        price: 15000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Nước uống"
    }, {
        _id: "21",
        name: "7UP Lon",
        image: food_22,
        price: 19000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Nước uống"
    }, {
        _id: "22",
        name: "Lipton",
        image: food_23,
        price: 15000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Nước uống"
    }, {
        _id: "23",
        name: "Pepsi Phúc Bồn Tử Lon",
        image: food_24,
        price: 19000,
        description: "Fastfood cung cấp năng lượng nhanh, ngon miệng và tiện cho cuộc sống bận rộn.",
        category: "Nước uống"
    }
]
